package com.laborsoftware.xpense.domain.enumeration;

public enum ExpenseState {
    RUNNING,
    PAUSED,
    FINISHED
}
