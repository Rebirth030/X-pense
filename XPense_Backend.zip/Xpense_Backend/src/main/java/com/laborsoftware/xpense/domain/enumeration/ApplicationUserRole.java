package com.laborsoftware.xpense.domain.enumeration;

public enum ApplicationUserRole {
    EMPLOYEE,
    FREELANCER,
    WORK_STUDENT,
    CUSTOM
}
